
This script is an asynchronous web scraping tool designed to scrape data from a specific website (https://www.fortiguard.com/encyclopedia?type=ips&risk={level}&page={i}) and store the scraped information in CSV files for further use. Although it has been mentioned in the original readme file that a script was somehow provided, I couldn't find it anywhere in the Github repository, nor in the readme file. Therefore, the following script was made without any consideration towards the aforementioned original script. With that being said, let's break it down in detail:

# 1. Importing Libraries

```python
import httpx
import asyncio
import json
from bs4 import BeautifulSoup
import polars as pl
from tqdm import tqdm
import time
import os
import random
```

- **httpx**: A library for making asynchronous HTTP requests. It's more efficient than the traditional `requests` library because it supports asynchronous programming, allowing multiple requests to be made concurrently.
- **asyncio**: A library for writing concurrent code using the `async` and `await` syntax. It is used to manage and run asynchronous tasks concurrently, which improves the performance of tasks like web scraping.
- **json**: A module for working with JSON data. In this script, it is used to store skipped pages in a JSON file.
- **BeautifulSoup**: A Python library for parsing HTML and XML documents. It is used here to extract data from the scraped HTML content.
- **polars**: A high-performance DataFrame library used to store and process structured data. In this case, it is used to save the scraped data as CSV files.
- **tqdm**: A progress bar library. It provides a visual representation of the progress of loops, which is useful for tracking the progress of scraping tasks.
- **time**: Used to measure the time taken for the scraping process.
- **os**: Provides functions to interact with the operating system, such as creating directories and checking for file existence.
- **random**: Used to introduce randomness into the request delays, preventing the scraper from being detected as a bot.

# 2. Configuration

```python
max_pages = [2, 5, 10, 20, 15]  # Maximum number of pages for each level
base_url = "https://www.fortiguard.com/encyclopedia?type=ips&risk={level}&page={i}"
```

- **max_pages**: A list that specifies the maximum number of pages to scrape for each risk level (from 1 to 5).
- **base_url**: The base URL template used to generate the full URL for each page at each risk level. `{level}` and `{i}` will be replaced with the actual risk level and page number, respectively.

# 3. Global Variable to Store Skipped Pages

```python
skipped_pages = {}
```

- **skipped_pages**: A dictionary that stores pages that were skipped due to errors (e.g., if the request fails). The key is the `level`, and the value is a list of page numbers that were skipped.

# 4. Asynchronous Function to Fetch HTML Content with Retries

```python
async def fetch_page(client, url, retries=3, delay=2):
    try:
        response = await client.get(url, timeout=10.0)
        response.raise_for_status()  # Ensure we throw an error on bad status codes
        return response.text
    except httpx.RequestError as e:
        print(f"Error fetching {url}: {e}")
        if retries > 0:
            print(f"Retrying {url} in {delay} seconds...")
            await asyncio.sleep(delay)  # Wait before retrying
            return await fetch_page(client, url, retries - 1, delay * 2)  # Exponentially increase delay
        else:
            # Log the error into a file
            with open('error_log.txt', 'a') as log_file:
                log_file.write(f"Failed to fetch {url} after retries
")
            return None
```

- **fetch_page**: This is the core function that makes asynchronous HTTP GET requests to fetch the HTML content of a page.
  - **client.get(url, timeout=10.0)**: Asynchronously sends a GET request to the specified URL. The `timeout=10.0` ensures that the request will time out if it takes longer than 10 seconds.
  - **response.raise_for_status()**: Checks if the HTTP response status code is a 2xx (successful). If not, it raises an exception.
  - If the request fails, the function retries up to `retries` times, with the delay between retries doubling each time (exponential backoff).
  - If all retries fail, the URL is logged to `error_log.txt`, and `None` is returned.
  
# 5. Function to Scrape Data from a Single Page

```python
async def scrape_page(client, level, page_number):
    url = base_url.format(level=level, i=page_number)
    html = await fetch_page(client, url)
    if html is None:
        return None

    # Parse HTML using BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')
    data = []

    # Find the articles (modify this as per actual HTML structure)
    articles = soup.find_all('article')  # Adjust this based on actual HTML tags
    for article in articles:
        title = article.find('h2').get_text(strip=True)  # Adjust as per actual tag
        link = article.find('a')['href']
        data.append({'title': title, 'link': link})

    return data
```

- **scrape_page**: This function scrapes data from a single page:
  - It first constructs the URL using the `base_url` template and the current `level` and `page_number`.
  - It then calls the `fetch_page` function to retrieve the HTML content.
  - If the HTML is retrieved successfully, it uses BeautifulSoup to parse the HTML and extract data.
  - Specifically, it looks for `article` tags, extracts the title from the `<h2>` tag, and the link from the `<a>` tag. The extracted data is stored in a dictionary with `title` and `link`.
  - The function returns a list of dictionaries containing the scraped data.

# 6. Function to Scrape All Pages for a Specific Level

```python
async def scrape_level(level, max_pages):
    async with httpx.AsyncClient() as client:
        all_data = []
        for page in range(1, max_pages[level-1] + 1):
            data = await scrape_page(client, level, page)
            if data:
                all_data.extend(data)
            else:
                if level not in skipped_pages:
                    skipped_pages[level] = []
                skipped_pages[level].append(page)

            # Add a random delay between requests to avoid rate limiting
            await asyncio.sleep(random.uniform(1, 3))  # Random delay between 1 and 3 seconds

        # Create a Polars DataFrame
        df = pl.DataFrame(all_data)
        
        # Save as CSV file
        df.write_csv(f"datasets/forti_lists_{level}.csv")
```

- **scrape_level**: This function coordinates scraping for all pages of a specific `level`:
  - It initializes an `httpx.AsyncClient()` to make requests asynchronously.
  - It then iterates through all the pages for the current level, calling `scrape_page` for each page.
  - The scraped data is collected in `all_data`.
  - If a page is skipped (due to an error), it is logged in the `skipped_pages` dictionary.
  - After all pages are scraped, the data is converted into a Polars DataFrame and saved as a CSV file named `forti_lists_{level}.csv`.

# 7. Main Function to Coordinate the Scraping

```python
async def main():
    # Create datasets directory if not exists
    if not os.path.exists("datasets"):
        os.makedirs("datasets")
    
    tasks = []
    for level in range(1, 6):
        tasks.append(scrape_level(level, max_pages))
    
    # Run all tasks concurrently
    await asyncio.gather(*tasks)

    # Save skipped pages as JSON
    if skipped_pages:
        with open('datasets/skipped.json', 'w') as f:
            json.dump(skipped_pages, f, indent=4)
```

- **main**: The orchestrator that coordinates the entire scraping process:
  - It ensures the `datasets` directory exists to store the CSV and JSON files.
  - It creates a list of tasks to scrape all levels (from 1 to 5), calling `scrape_level` for each level.
  - It runs all tasks concurrently using `asyncio.gather(*tasks)`.
  - After scraping is completed, it saves the skipped pages (if any) to `datasets/skipped.json`.

# 8. Entry Point for Jupyter/Interactive Environments

```python
if __name__ == '__main__':
    start_time = time.time()
    await main()  # Directly use await instead of asyncio.run()
    print(f"Scraping completed in {time.time() - start_time:.2f} seconds.")
```

- **Entry Point**: 
  - This block ensures that the script runs only when executed directly (not imported as a module).
  - It measures the time taken to execute the entire scraping process and prints the elapsed time after completion.
  - Since this script is designed for environments like Jupyter, it uses `await main()` directly instead of `asyncio.run(main())`.

# Summary:
This script efficiently scrapes data from a set of web pages asynchronously, handles potential errors (with retries and exponential backoff), and saves the results in CSV files. It also handles rate limiting by introducing random delays between requests and logs any errors or skipped pages for later review. The use of asynchronous programming significantly improves the scraping performance compared to synchronous methods. That being said, I somehow always encountered the `httpx.RequestError` when scraping the web. As a result, everything ran smoothly except for the fact that the generated `forti_lists.csv` files from 1 to 5 has no data whatsoever in them. And the documented skipped pages in the `skipped.json` file account for **all** of the pages accessed (meaning every page was skipped due to the aforementioned `httpx.RequestError`). Therefore, I would really appreciate it if the reader would point out what oversights I have made, that makes me consistently encountering the `httpx.RequestError`.
