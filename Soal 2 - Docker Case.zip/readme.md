# **1. `api.py` (API file)**

This file contains a FastAPI web application that exposes an endpoint `/predict`.

1. **FastAPI** is imported to create the API and handle requests.
    
2. The **`/predict`** endpoint accepts a POST request with a text input and performs the following:
    
    -   It uses the **MD5 hashing algorithm** to hash the input text.
        
    -   Then, it calculates the result as **`hashed % 4`** and returns this value as the response.
        
3. The FastAPI application runs on port **6000** using **Uvicorn** (an ASGI server) when executed.

# **2. `Dockerfile` for API**

This Dockerfile builds the container image for the API.

1. **Base Image**: It uses the official Python 3.9 slim image from Docker Hub.
    
2. **Working Directory**: It sets **`/app`** as the working directory inside the container.
    
3. **Dependencies**: It copies **`requirements.txt`** into the container and installs the necessary dependencies listed there using **`pip`**.
    
4. **Copying the API code**: It copies the **`api.py`** file into the container.
    
5. **Expose Port**: It exposes port **6000** to match the port defined in **`api.py`**.
    
6. **Run Command**: When the container runs, it starts the API service by executing `python api.py`.

# **3. `requirements.txt` for API**

This file lists the Python dependencies required by the API.

1. **`uvicorn`**: The ASGI server used to run the FastAPI app.
    
2. **`fastapi`**: The FastAPI framework for building the API.

# **4. `etl.py` (ETL file)**

This script performs an ETL operation, specifically calling the `/predict` API endpoint.

1. **Sentences**: A list of sample sentences is defined to send to the API.
    
2. **HTTP Requests**: It uses **`httpx`** to asynchronously send a POST request to the **`/predict`** API endpoint with each sentence.
    
3. **Response Handling**: It prints the response from the API, which will be the result of the **`hashed % 4`** calculation.
    
4. **Asynchronous Execution**: The script runs asynchronously to handle multiple requests concurrently.

# **5. `Dockerfile` for ETL**

This Dockerfile builds the container image for the ETL script.

1. **Base Image**: Similar to the API Dockerfile, it uses the official Python 3.9 slim image.
    
2. **Working Directory**: It sets **`/app`** as the working directory.
    
3. **Dependencies**: It installs the dependencies listed in **`requirements.txt`**.
    
4. **Copying the ETL script**: It copies **`etl.py`** into the container.
    
5. **Run Command**: When the container runs, it executes the ETL script using **`python etl.py`**.

# **6. `requirements.txt` for ETL**

This file lists the Python dependency required by the ETL process.

1. **`httpx`**: Used for making asynchronous HTTP requests.

# **7. `docker-compose.yml`**

This file is used to define and run multi-container Docker applications.

1. **API Service**:
    
    -   It builds the API container from the **`./api`** directory.
        
    -   Exposes port **6000** on the host and maps it to the API container's port **6000**.
        
    -   It joins the **`app_network`** network.
        
2. **ETL Service**:
    
    -   It builds the ETL container from the **`./etl`** directory.
        
    -   It depends on the API service, ensuring that the API is running before the ETL starts.
        
    -   It also joins the **`app_network`** network.
        
3. **Network**:
    
    -   The services communicate over the **`app_network`** bridge network.

# **Summary**

1. The **API** provides a simple **`/predict`** endpoint to process text input and return a hashed result.
    
2. The **ETL** script makes requests to this API, processes the results, and is encapsulated in a Docker container.
    
3. Docker Compose is used to orchestrate both services (API and ETL) and manage their dependencies and communication.